import { Component } from '@angular/core';

@Component({
  selector: 'app-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['./quote.component.css']
})
export class QuoteComponent {
  quotes: string[] = [
    'The only limit to our realization of tomorrow is our doubts of today. - Franklin D. Roosevelt',
    'In the end, we will remember not the words of our enemies, but the silence of our friends. - Martin Luther King Jr.',
    'The best way to predict the future is to invent it. - Alan Kay',
    'Life is 10% what happens to us and 90% how we react to it. - Charles R. Swindoll',
    'The only way to do great work is to love what you do. - Steve Jobs'
  ];
}
