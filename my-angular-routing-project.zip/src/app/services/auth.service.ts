import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isAuthenticated = false;

  login(username: string, password: string): Observable<boolean> {
    // Mock authentication
    if (username === 'user' && password === 'password') {
      this.isAuthenticated = true;
      localStorage.setItem('token', 'mock-token');
      return of(true);
    }
    return of(true);
  }

  logout(): void {
    this.isAuthenticated = false;
    localStorage.removeItem('token');
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }
}
