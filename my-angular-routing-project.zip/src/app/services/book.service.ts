import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { Book } from '../models/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private books: Book[] = [
    { id: 1, title: 'Book 1', author: 'Author 1', publicationDate: new Date() },
    { id: 2, title: 'Book 2', author: 'Author 2', publicationDate: new Date() }
  ];

  getBooks(): Observable<Book[]> {
    return of(this.books);
  }

  getBook(id: number): Observable<Book> {
    const book = this.books.find(b => b.id === id);
    if (book) {
      return of(book);
    } else {
      return throwError(() => new Error('Book not found'));
    }
  }

  addBook(book: Book): Observable<void> {
    book.id = this.books.length + 1;
    this.books.push(book);
    return of(void 0); // Return Observable<void>
  }

  updateBook(book: Book): Observable<void> {
    const index = this.books.findIndex(b => b.id === book.id);
    if (index !== -1) {
      this.books[index] = book;
    }
    return of(void 0); // Return Observable<void>
  }

  deleteBook(id: number): Observable<void> {
    this.books = this.books.filter(b => b.id !== id);
    console.log('Book deleted:', this.books);
    return of(void 0); // Return Observable<void>
  }
}
