import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isAuthenticated = false;

  login(username: string, password: string): Observable<boolean> {
    // Mock authentication
    if (username === 'user' && password === 'password') {
      this.isAuthenticated = true;
      return of(true);
    }
    return of(false);
  }

  logout(): void {
    this.isAuthenticated = false;
  }

  getToken(): string {
    return this.isAuthenticated ? 'mock-token' : '';
  }
}
