export const environment = {
    production: true,
    apiUrl: 'https://book-app-hhdydmc2ehazgrht.eastus-01.azurewebsites.net/api'
  };
  